#!/usr/bin/env python3
import argparse
import os
from datetime import datetime

import pandas as pd

from itransformer_common import (
    expected_rows,
    finite_metric,
    normalize_summary,
    protocol_key_columns,
    read_existing_summaries,
    with_source_priority,
)


def reusable_runs(expected, summaries):
    keys = protocol_key_columns()
    if summaries.empty:
        return pd.DataFrame(columns=list(expected.columns) + ["mse", "mae", "summary_path"])
    summaries = normalize_summary(summaries)
    usable = summaries[
        summaries.get("mse", pd.Series(dtype=float)).map(finite_metric)
        & summaries.get("mae", pd.Series(dtype=float)).map(finite_metric)
    ].copy()
    if usable.empty:
        return pd.DataFrame(columns=list(expected.columns) + ["mse", "mae", "summary_path"])
    usable = with_source_priority(usable)
    keep_cols = keys + [
        col for col in ["mse", "mae", "summary_path", "setting", "config_path", "pred_path", "true_path", "run_id", "server_id", "server_ip"]
        if col in usable.columns
    ]
    usable = usable.sort_values(keys + ["_source_priority", "summary_path"]).drop_duplicates(keys, keep="last")
    usable = usable[[col for col in keep_cols if col in usable.columns]]
    return expected.merge(usable, on=keys, how="inner")


def main():
    parser = argparse.ArgumentParser(description="Build iTransformer expected/reusable/missing matrix")
    parser.add_argument("--stage", choices=["smoke", "stage1", "placement_probe"], default="stage1")
    parser.add_argument("--output_dir", default=".aris")
    parser.add_argument("--tag", default="")
    parser.add_argument("--train_epochs", type=int, default=10)
    parser.add_argument("--batch_size", type=int, default=32)
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    tag = args.tag or f"itransformer_{args.stage}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    expected = expected_rows(args.stage, train_epochs=args.train_epochs, batch_size=args.batch_size)
    reusable = reusable_runs(expected, read_existing_summaries())
    keys = protocol_key_columns()
    missing = expected.merge(reusable[keys].drop_duplicates(), on=keys, how="left", indicator=True)
    missing = missing[missing["_merge"] == "left_only"].drop(columns=["_merge"])

    expected_path = os.path.join(args.output_dir, f"itransformer_expected_matrix_{tag}.csv")
    reusable_path = os.path.join(args.output_dir, f"itransformer_reusable_runs_{tag}.csv")
    missing_path = os.path.join(args.output_dir, f"itransformer_missing_runs_{tag}.csv")
    report_path = os.path.join(args.output_dir, f"itransformer_reuse_report_{tag}.md")
    expected.to_csv(expected_path, index=False)
    reusable.to_csv(reusable_path, index=False)
    missing.to_csv(missing_path, index=False)
    with open(report_path, "w", encoding="utf-8") as handle:
        handle.write("# iTransformer Reuse Report\n\n")
        handle.write(f"- Stage: `{args.stage}`\n")
        handle.write(f"- Expected seed-runs: `{len(expected)}`\n")
        handle.write(f"- Reusable seed-runs: `{len(reusable)}`\n")
        handle.write(f"- Missing seed-runs: `{len(missing)}`\n")
    print(expected_path)
    print(reusable_path)
    print(missing_path)
    print(report_path)


if __name__ == "__main__":
    main()
