#!/usr/bin/env python3
import argparse
import json
import os
import shlex
from datetime import datetime

import pandas as pd

from itransformer_common import CONFIGS, HOST_PRIORITY, setting_name


def shell_join(args):
    return " ".join(shlex.quote(str(arg)) for arg in args)


def server_id_for_host(host):
    return host.replace("10.21.53.", "4090-")


def command_for_row(row, run_tag, server_id, server_ip):
    config = CONFIGS[row["config_name"]]
    des = f"{run_tag}_{row['config_name']}_s{int(row['seed'])}"
    model_id = f"{row['dataset']}_pl{int(row['pred_len'])}_{row['config_name']}_s{int(row['seed'])}"
    args = [
        "python",
        "-u",
        "run.py",
        "--random_seed",
        int(row["seed"]),
        "--is_training",
        1,
        "--root_path",
        row["root_path"],
        "--data_path",
        row["data_path"],
        "--model_id",
        model_id,
        "--model",
        "iTransformer",
        "--data",
        row["data"],
        "--features",
        "M",
        "--target",
        row["target"],
        "--freq",
        row["freq"],
        "--seq_len",
        int(row["seq_len"]),
        "--label_len",
        int(row["label_len"]),
        "--pred_len",
        int(row["pred_len"]),
        "--enc_in",
        7,
        "--dec_in",
        7,
        "--c_out",
        7,
        "--e_layers",
        int(row["e_layers"]),
        "--d_layers",
        int(row["d_layers"]),
        "--n_heads",
        int(row["n_heads"]),
        "--d_model",
        int(row["d_model"]),
        "--d_ff",
        int(row["d_ff"]),
        "--factor",
        int(row["factor"]),
        "--dropout",
        float(row["dropout"]),
        "--embed",
        row["embed"],
        "--des",
        des,
        "--train_epochs",
        int(row["train_epochs"]),
        "--patience",
        3,
        "--itr",
        1,
        "--batch_size",
        int(row["batch_size"]),
        "--learning_rate",
        row["learning_rate"],
        "--num_workers",
        4,
        "--activation",
        config["activation"],
        "--output_activation",
        config.get("output_activation", "linear"),
        "--gpu",
        "${GPU}",
        "--config_name",
        row["config_name"],
        "--stage",
        row["stage"],
        "--server_id",
        server_id,
        "--server_ip",
        server_ip,
        "--run_id",
        run_tag,
    ]
    return shell_join(args)


def build_payloads(missing, hosts, run_tag, remote_cwd, venv_path, max_parallel, gpus):
    manifests = {host: [] for host in hosts}
    for idx, row in enumerate(missing.sort_values(["dataset", "pred_len", "config_name", "seed"]).to_dict("records")):
        host = hosts[idx % len(hosts)]
        server_id = server_id_for_host(host)
        job_id = f"it_stage1_{row['dataset']}_pl{int(row['pred_len'])}_{row['config_name']}_s{int(row['seed'])}"
        expected_output = f"results/{setting_name(row, run_tag)}/config.json"
        manifests[host].append(
            {
                "id": job_id,
                "cmd": command_for_row(row, run_tag, server_id, host),
                "expected_output": expected_output,
            }
        )
    payloads = {}
    for host, jobs in manifests.items():
        payloads[host] = {
            "project": f"itransformer_activation_transfer_{host}",
            "cwd": remote_cwd,
            "venv_path": venv_path,
            "gpus": gpus,
            "max_parallel": max_parallel,
            "gpu_free_threshold_mib": 500,
            "oom_retry": {"delay": 180, "max_attempts": 2},
            "phases": [{"name": "stage1", "depends_on": [], "jobs": jobs}] if jobs else [],
        }
    return payloads


def main():
    parser = argparse.ArgumentParser(description="Build iTransformer remote queue manifests")
    parser.add_argument("missing_runs_csv")
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--run_tag", default="")
    parser.add_argument("--host", action="append", default=[])
    parser.add_argument("--remote_cwd", default="/home/testsv/project/osc_informer/iTransformer")
    parser.add_argument("--venv_path", default="/home/testsv/project/osc_informer/lee_ocil/.venv")
    parser.add_argument("--max_parallel", type=int, default=1)
    parser.add_argument("--gpus", default="0")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    missing = pd.read_csv(args.missing_runs_csv)
    run_tag = args.run_tag or f"itransformer_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    hosts = args.host or HOST_PRIORITY
    gpus = [int(item) for item in args.gpus.split(",") if item.strip()]
    payloads = build_payloads(missing, hosts, run_tag, args.remote_cwd, args.venv_path, args.max_parallel, gpus)
    rows = []
    for host, payload in payloads.items():
        job_count = sum(len(phase["jobs"]) for phase in payload["phases"])
        if not job_count:
            continue
        path = os.path.join(args.output_dir, f"itransformer_queue_manifest_{host.replace('.', '_')}.json")
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2)
        rows.append({"host": host, "jobs": job_count, "manifest": path})
        print(f"Wrote {path}: {job_count} jobs")
    pd.DataFrame(rows).to_csv(os.path.join(args.output_dir, "itransformer_queue_manifest_summary.csv"), index=False)


if __name__ == "__main__":
    main()
