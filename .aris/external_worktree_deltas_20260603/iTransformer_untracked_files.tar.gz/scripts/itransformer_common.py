import glob
import math
import os
import re

import pandas as pd


SEEDS = [2024]
HOST_PRIORITY = ["10.21.53.82", "10.21.53.113", "10.21.53.142", "10.21.53.162"]

CONFIGS = {
    "gelu_ffn_linear": {"activation": "gelu", "amplitude": 0.0, "output_activation": "linear"},
    "relu_ffn_linear": {"activation": "relu", "amplitude": 0.0, "output_activation": "linear"},
    "swish_ffn_linear": {"activation": "swish", "amplitude": 0.0, "output_activation": "linear"},
    "tanh_ffn_linear": {"activation": "tanh", "amplitude": 0.0, "output_activation": "linear"},
    "softsign_ffn_linear": {"activation": "softsign", "amplitude": 0.0, "output_activation": "linear"},
    "tanh_sin001_ffn_linear": {"activation": "tanh_sin001", "amplitude": 0.01, "output_activation": "linear"},
    "gelu_ffn_outtanh": {"activation": "gelu", "amplitude": 0.0, "output_activation": "tanh"},
    "relu_ffn_outtanh": {"activation": "relu", "amplitude": 0.0, "output_activation": "tanh"},
    "swish_ffn_outtanh": {"activation": "swish", "amplitude": 0.0, "output_activation": "tanh"},
    "tanh_ffn_outtanh": {"activation": "tanh", "amplitude": 0.0, "output_activation": "tanh"},
    "softsign_ffn_outtanh": {"activation": "softsign", "amplitude": 0.0, "output_activation": "tanh"},
    "tanh_sin001_ffn_outtanh": {"activation": "tanh_sin001", "amplitude": 0.01, "output_activation": "tanh"},
}

STAGE1_CONFIGS = [
    "gelu_ffn_linear",
    "tanh_ffn_linear",
    "softsign_ffn_linear",
    "tanh_sin001_ffn_linear",
]
PLACEMENT_PROBE_CONFIGS = list(CONFIGS)
PRED_LENS = [96, 336, 720]
DATASETS = ["ETTh2", "ETTm2"]
PLACEMENT_PROBE_CELLS = [
    ("ETTh2", 96),
    ("ETTm2", 96),
    ("ETTm2", 720),
]
SMOKE_ROWS = {
    ("ETTh2", 96, "gelu_ffn_linear", 2024),
    ("ETTh2", 96, "tanh_ffn_linear", 2024),
}

SUMMARY_GLOBS = [
    "iTransformer/results/summary.csv",
    "itransformer_remote_results/*/results/summary.csv",
    "itransformer_remote_results/*/*/results/summary.csv",
]


def activation_signature(config_name):
    config = CONFIGS[config_name]
    activation = config["activation"]
    output = "tanh" if str(config.get("output_activation", "linear")).lower() == "tanh" else "linear"
    return f"act={activation}|ffn={activation}|out={output}|a={float(config['amplitude']):g}"


def config_from_signature(signature, placement=None):
    for name in CONFIGS:
        config = CONFIGS[name]
        expected_placement = "ffn_outtanh" if config.get("output_activation") == "tanh" else "ffn_linear"
        if activation_signature(name) == signature and (placement is None or placement == expected_placement):
            return name
    return ""


def dataset_protocol(dataset):
    if dataset == "ETTh2":
        return {
            "data": "ETTh2",
            "root_path": "../lee_ocil/ETT-small/",
            "data_path": "ETTh2.csv",
            "target": "OT",
            "freq": "h",
        }
    if dataset == "ETTm2":
        return {
            "data": "ETTm2",
            "root_path": "../lee_ocil/ETT-small/",
            "data_path": "ETTm2.csv",
            "target": "OT",
            "freq": "t",
        }
    raise ValueError(f"Unsupported iTransformer dataset: {dataset}")


def expected_rows(stage, train_epochs=10, batch_size=32):
    rows = []
    if stage == "smoke":
        source = SMOKE_ROWS
    elif stage == "placement_probe":
        source = {
            (dataset, pred_len, config_name, seed)
            for dataset, pred_len in PLACEMENT_PROBE_CELLS
            for config_name in PLACEMENT_PROBE_CONFIGS
            for seed in SEEDS
        }
    else:
        source = {
        (dataset, pred_len, config_name, seed)
        for dataset in DATASETS
        for pred_len in PRED_LENS
        for config_name in STAGE1_CONFIGS
        for seed in SEEDS
        }
    for dataset, pred_len, config_name, seed in sorted(source):
        rows.append(row_for(dataset, pred_len, config_name, seed, stage, train_epochs, batch_size))
    return pd.DataFrame(rows)


def row_for(dataset, pred_len, config_name, seed, stage, train_epochs, batch_size):
    config = CONFIGS[config_name]
    return {
        "stage": stage,
        "dataset": dataset,
        "pred_len": int(pred_len),
        "config_name": config_name,
        "activation": config["activation"],
        "output_activation": config.get("output_activation", "linear"),
        "activation_signature": activation_signature(config_name),
        "placement": "ffn_outtanh" if config.get("output_activation") == "tanh" else "ffn_linear",
        "seed": int(seed),
        "batch_size": int(batch_size),
        "train_epochs": int(train_epochs),
        "seq_len": 96,
        "label_len": 48,
        "e_layers": 2,
        "d_layers": 1,
        "d_model": 128,
        "n_heads": 8,
        "d_ff": 128,
        "factor": 1,
        "dropout": 0.1,
        "learning_rate": 1e-4,
        "features": "M",
        "model": "iTransformer",
        "embed": "timeF",
        "class_strategy": "projection",
        **dataset_protocol(dataset),
    }


def setting_name(row, run_tag):
    model_id = f"{row['dataset']}_pl{int(row['pred_len'])}_{row['config_name']}_s{int(row['seed'])}"
    des = f"{run_tag}_{row['config_name']}_s{int(row['seed'])}"
    # Match iTransformer/run.py exactly. The upstream format string uses legacy
    # labels whose names are shifted relative to the values.
    return (
        f"{model_id}_iTransformer_{row['data']}_{row['features']}_ft{int(row['seq_len'])}"
        f"_sl{int(row['label_len'])}_ll{int(row['pred_len'])}_pl{int(row['d_model'])}"
        f"_dm{int(row['n_heads'])}_nh{int(row['e_layers'])}_el{int(row['d_layers'])}"
        f"_dl{int(row['d_ff'])}_df{int(row['factor'])}_fc{row['embed']}"
        f"_ebTrue_dt{des}_{row['class_strategy']}_0"
    )


def protocol_key_columns():
    return [
        "dataset",
        "pred_len",
        "seq_len",
        "label_len",
        "e_layers",
        "d_layers",
        "d_model",
        "n_heads",
        "d_ff",
        "factor",
        "batch_size",
        "train_epochs",
        "activation_signature",
        "placement",
        "seed",
    ]


def read_existing_summaries():
    frames = []
    for pattern in SUMMARY_GLOBS:
        for path in glob.glob(pattern):
            try:
                frame = pd.read_csv(path)
            except (OSError, pd.errors.EmptyDataError):
                continue
            frame["summary_path"] = path
            frames.append(frame)
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def normalize_summary(summary):
    if summary.empty:
        return summary
    df = summary.copy()
    if "stage" not in df.columns:
        df["stage"] = ""
    if "run_id" in df.columns:
        run_id = df["run_id"].fillna("").astype(str)
        df.loc[df["stage"].eq("") & run_id.str.contains("stage1", regex=False), "stage"] = "stage1"
    if "dataset" not in df.columns:
        df["dataset"] = df.get("data", "")
    if "activation_signature" not in df.columns:
        df["activation_signature"] = df["activation"].fillna("").map(
            lambda act: f"act={act}|ffn={act}|out=linear|a={0.01 if act in {'tanh_sin001', 'tanh_sin'} else 0:g}"
        )
    if "placement" not in df.columns:
        df["placement"] = "ffn_linear"
    if "output_activation" not in df.columns:
        df["output_activation"] = df["placement"].fillna("").map(lambda item: "tanh" if item == "ffn_outtanh" else "linear")
    numeric = [
        "pred_len", "seq_len", "label_len", "e_layers", "d_layers", "d_model",
        "n_heads", "d_ff", "factor", "batch_size", "train_epochs", "seed",
        "mse", "mae"
    ]
    for col in numeric:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    return df


def finite_metric(value):
    try:
        return math.isfinite(float(value))
    except (TypeError, ValueError):
        return False


def with_source_priority(df):
    out = df.copy()
    out["_source_priority"] = 0
    if "run_id" not in out.columns or "summary_path" not in out.columns:
        return out
    path = out["summary_path"].fillna("").astype(str)
    out.loc[path.str.contains("stage1", regex=False), "_source_priority"] = 1
    return out
