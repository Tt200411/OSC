#!/usr/bin/env python3
import argparse
import os

import pandas as pd

from itransformer_common import config_from_signature, finite_metric, normalize_summary, protocol_key_columns, read_existing_summaries, with_source_priority


CELL_COLS = [
    "dataset",
    "pred_len",
    "seq_len",
    "label_len",
    "e_layers",
    "d_layers",
    "d_model",
    "n_heads",
    "d_ff",
    "factor",
    "batch_size",
    "train_epochs",
]
KEYS = CELL_COLS + ["config_name", "activation_signature", "placement", "seed"]


def markdown_table(frame):
    if frame.empty:
        return "No rows."
    cols = list(frame.columns)
    lines = [
        "| " + " | ".join(cols) + " |",
        "| " + " | ".join(["---"] * len(cols)) + " |",
    ]
    for row in frame.to_dict("records"):
        lines.append("| " + " | ".join(str(row.get(col, "")) for col in cols) + " |")
    return "\n".join(lines)


def add_config_names(df):
    out = df.copy()
    out["config_name"] = out.apply(
        lambda row: row.get("config_name") if isinstance(row.get("config_name"), str) and row.get("config_name") else config_from_signature(row.get("activation_signature", ""), row.get("placement", None)),
        axis=1,
    )
    return out


def aggregate(raw):
    group_cols = CELL_COLS + ["config_name", "activation_signature", "placement"]
    return (
        raw.groupby(group_cols, dropna=False)
        .agg(
            seed_count=("seed", "nunique"),
            mse_mean=("mse", "mean"),
            mse_std=("mse", "std"),
            mae_mean=("mae", "mean"),
            mae_std=("mae", "std"),
        )
        .reset_index()
    )


def paired_vs_gelu(raw):
    merge_cols = CELL_COLS + ["seed"]
    baseline = raw[raw["config_name"] == "gelu_ffn_linear"][merge_cols + ["mse", "mae"]].rename(
        columns={"mse": "gelu_mse", "mae": "gelu_mae"}
    )
    paired = raw.merge(baseline, on=merge_cols, how="left")
    paired["improvement_vs_gelu"] = (paired["gelu_mse"] - paired["mse"]) / paired["gelu_mse"]
    paired["win_vs_gelu"] = paired["mse"] < paired["gelu_mse"]
    return paired


def best_cells(agg_df):
    eligible = agg_df[agg_df["seed_count"] >= 1].copy()
    if eligible.empty:
        return eligible
    eligible["rank"] = eligible.groupby(CELL_COLS)["mse_mean"].rank(method="min")
    return eligible[eligible["rank"] == 1].sort_values(["dataset", "pred_len"])


def write_claim_summary(path, raw, agg_df, paired):
    best = best_cells(agg_df)
    non_gelu_best = int((best["config_name"] != "gelu_ffn_linear").sum()) if not best.empty else 0
    total_cells = best[CELL_COLS].drop_duplicates().shape[0] if not best.empty else 0
    ranked = agg_df.copy()
    if not ranked.empty:
        ranked["rank_in_cell"] = ranked.groupby(CELL_COLS)["mse_mean"].rank(method="min")
        static = (
            ranked.groupby("config_name")
            .agg(
                mean_rank=("rank_in_cell", "mean"),
                best_cells=("rank_in_cell", lambda x: int((x == 1).sum())),
                mean_mse=("mse_mean", "mean"),
            )
            .reset_index()
            .sort_values(["mean_rank", "mean_mse"])
        )
    else:
        static = pd.DataFrame()
    paired_complete = paired[paired["gelu_mse"].map(finite_metric)].copy()
    lines = [
        "# iTransformer Activation Transfer Claim Summary",
        "",
        f"- Raw finite seed-runs: {len(raw)}",
        f"- Complete config cells: {len(agg_df)}",
        f"- Dataset-horizon cells with non-GELU best activation: {non_gelu_best}/{total_cells}",
        "",
        "## Static Ranking",
        "",
        markdown_table(static),
        "",
        "## Best Cells",
        "",
        markdown_table(best[["dataset", "pred_len", "config_name", "mse_mean", "mae_mean", "rank"]] if not best.empty else best),
    ]
    if not paired_complete.empty:
        paired_summary = (
            paired_complete.groupby("config_name")
            .agg(
                seed_win_rate=("win_vs_gelu", "mean"),
                mean_gain_vs_gelu=("improvement_vs_gelu", "mean"),
                paired_seed_runs=("improvement_vs_gelu", "size"),
            )
            .reset_index()
            .sort_values("mean_gain_vs_gelu", ascending=False)
        )
        lines.extend(["", "## Paired vs GELU", "", markdown_table(paired_summary)])
    with open(path, "w", encoding="utf-8") as handle:
        handle.write("\n".join(lines) + "\n")


def main():
    parser = argparse.ArgumentParser(description="Aggregate iTransformer activation transfer results")
    parser.add_argument("--output_dir", default="itransformer_remote_results/analysis_current")
    parser.add_argument("--run_id_contains", default="")
    parser.add_argument("--train_epochs", type=int, default=None)
    parser.add_argument("--expected_csv", default="", help="Optional expected matrix used to filter and attach reused runs")
    args = parser.parse_args()
    os.makedirs(args.output_dir, exist_ok=True)
    raw = read_existing_summaries()
    if raw.empty:
        raise SystemExit("No iTransformer summaries found")
    raw = normalize_summary(raw)
    raw = raw[raw["mse"].map(finite_metric) & raw["mae"].map(finite_metric)].copy()
    if args.run_id_contains:
        raw = raw[raw.get("run_id", "").astype(str).str.contains(args.run_id_contains, regex=False)].copy()
    if args.train_epochs is not None and "train_epochs" in raw.columns:
        raw = raw[raw["train_epochs"].eq(args.train_epochs)].copy()
    raw = add_config_names(raw)
    raw = raw[raw["config_name"] != ""].copy()
    raw = with_source_priority(raw)
    if args.expected_csv:
        expected = pd.read_csv(args.expected_csv)
        raw = expected[protocol_key_columns() + ["config_name"]].merge(
            raw,
            on=protocol_key_columns(),
            how="left",
            suffixes=("_expected", ""),
        )
        if "config_name_expected" in raw.columns:
            raw = raw[raw["config_name"].eq(raw["config_name_expected"])].copy()
            raw = raw.drop(columns=["config_name_expected"])
        raw = raw[raw["mse"].map(finite_metric) & raw["mae"].map(finite_metric)].copy()
    raw = raw.sort_values(["dataset", "pred_len", "config_name", "placement", "seed", "_source_priority", "summary_path"]).drop_duplicates(KEYS, keep="last")
    raw = raw.drop(columns=["_source_priority"], errors="ignore")
    agg_df = aggregate(raw)
    paired = paired_vs_gelu(raw)

    raw.to_csv(os.path.join(args.output_dir, "itransformer_protocol_raw_dedup.csv"), index=False)
    agg_df.to_csv(os.path.join(args.output_dir, "itransformer_protocol_aggregate.csv"), index=False)
    paired.to_csv(os.path.join(args.output_dir, "itransformer_paired_vs_gelu.csv"), index=False)
    best_cells(agg_df).to_csv(os.path.join(args.output_dir, "itransformer_best_cells.csv"), index=False)
    summary_path = os.path.join(args.output_dir, "itransformer_claim_summary.md")
    write_claim_summary(summary_path, raw, agg_df, paired)
    print(summary_path)


if __name__ == "__main__":
    main()
