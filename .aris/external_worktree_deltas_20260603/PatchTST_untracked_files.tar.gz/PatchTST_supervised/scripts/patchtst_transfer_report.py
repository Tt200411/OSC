#!/usr/bin/env python3
import argparse
import os

import pandas as pd

from patchtst_common import (
    config_from_signature,
    finite_metric,
    normalize_summary,
    read_existing_summaries,
    with_source_priority,
)


CELL_COLS = [
    "dataset",
    "pred_len",
    "seq_len",
    "patch_len",
    "stride",
    "e_layers",
    "d_model",
    "n_heads",
    "d_ff",
    "batch_size",
    "train_epochs",
]
KEYS = CELL_COLS + ["config_name", "activation_signature", "placement", "seed"]
STAGE2_CELLS = {
    ("ETTh2", 336),
    ("ETTh2", 720),
    ("ETTm2", 288),
    ("ETTm2", 672),
    ("Solar3", 96),
    ("Solar5", 96),
}
PLACEMENT_PAIRS = {
    "gelu": ("gelu_ffn_linear", "gelu_ffn_outtanh"),
    "tanh": ("tanh_ffn_linear", "tanh_ffn_outtanh"),
    "tanh_sin001": ("tanh_sin001_ffn_linear", "tanh_sin001_ffn_outtanh"),
}


def markdown_table(frame, max_rows=None):
    if frame.empty:
        return "No rows."
    shown = frame.head(max_rows) if max_rows else frame
    cols = list(shown.columns)
    lines = [
        "| " + " | ".join(cols) + " |",
        "| " + " | ".join(["---"] * len(cols)) + " |",
    ]
    for row in shown.to_dict("records"):
        lines.append("| " + " | ".join(str(row.get(col, "")) for col in cols) + " |")
    return "\n".join(lines)


def add_config_names(df):
    out = df.copy()
    out["config_name"] = out.apply(
        lambda row: config_from_signature(row.get("activation_signature", ""), row.get("placement", None)),
        axis=1,
    )
    return out


def load_raw(run_ids, train_epochs):
    raw = read_existing_summaries()
    if raw.empty:
        return raw
    raw = normalize_summary(raw)
    raw = raw[raw["mse"].map(finite_metric) & raw["mae"].map(finite_metric)].copy()
    if run_ids:
        raw = raw[raw.get("run_id", "").astype(str).isin(run_ids)].copy()
    if train_epochs is not None:
        raw = raw[raw["train_epochs"].eq(train_epochs)].copy()
    raw = add_config_names(raw)
    raw = raw[raw["config_name"] != ""].copy()
    raw = with_source_priority(raw)
    raw = raw.sort_values(["dataset", "pred_len", "config_name", "seed", "_source_priority", "summary_path"]).drop_duplicates(KEYS, keep="last")
    return raw.drop(columns=["_source_priority"], errors="ignore")


def aggregate(raw):
    group_cols = CELL_COLS + ["config_name", "activation_signature", "placement"]
    if raw.empty:
        return pd.DataFrame(columns=group_cols + ["seed_count", "mse_mean", "mse_std", "mae_mean", "mae_std"])
    return (
        raw.groupby(group_cols, dropna=False)
        .agg(
            seed_count=("seed", "nunique"),
            mse_mean=("mse", "mean"),
            mse_std=("mse", "std"),
            mae_mean=("mae", "mean"),
            mae_std=("mae", "std"),
        )
        .reset_index()
    )


def rank_configs(agg_df):
    complete = agg_df[agg_df["seed_count"] >= 3].copy()
    if complete.empty:
        return complete
    complete["rank_in_cell"] = complete.groupby(CELL_COLS)["mse_mean"].rank(method="min")
    return complete


def best_cells(agg_df):
    ranked = rank_configs(agg_df)
    if ranked.empty:
        return ranked
    return ranked[ranked["rank_in_cell"] == 1].sort_values(["dataset", "pred_len", "config_name"])


def static_ranking(agg_df):
    ranked = rank_configs(agg_df)
    if ranked.empty:
        return pd.DataFrame()
    return (
        ranked.groupby("config_name", dropna=False)
        .agg(
            mean_rank=("rank_in_cell", "mean"),
            best_cells=("rank_in_cell", lambda x: int((x == 1).sum())),
            mean_mse=("mse_mean", "mean"),
        )
        .reset_index()
        .sort_values(["mean_rank", "mean_mse"])
    )


def placement_paired(raw):
    rows = []
    for base_activation, (linear_name, out_name) in PLACEMENT_PAIRS.items():
        linear = raw[raw["config_name"] == linear_name].copy()
        out = raw[raw["config_name"] == out_name].copy()
        if linear.empty or out.empty:
            continue
        linear = linear[linear.apply(lambda r: (r["dataset"], int(r["pred_len"])) in STAGE2_CELLS, axis=1)]
        out = out[out.apply(lambda r: (r["dataset"], int(r["pred_len"])) in STAGE2_CELLS, axis=1)]
        merge_cols = CELL_COLS + ["seed"]
        paired = linear[merge_cols + ["mse", "mae"]].rename(columns={"mse": "linear_mse", "mae": "linear_mae"}).merge(
            out[merge_cols + ["mse", "mae"]].rename(columns={"mse": "outtanh_mse", "mae": "outtanh_mae"}),
            on=merge_cols,
            how="inner",
        )
        paired["base_activation"] = base_activation
        paired["output_tanh_gain"] = (paired["linear_mse"] - paired["outtanh_mse"]) / paired["linear_mse"]
        paired["output_tanh_win"] = paired["outtanh_mse"] < paired["linear_mse"]
        rows.append(paired)
    if not rows:
        return pd.DataFrame()
    return pd.concat(rows, ignore_index=True)


def baseline_paired(raw):
    baseline = raw[raw["config_name"] == "gelu_ffn_linear"][CELL_COLS + ["seed", "mse"]].rename(columns={"mse": "gelu_linear_mse"})
    paired = raw.merge(baseline, on=CELL_COLS + ["seed"], how="left")
    paired = paired[paired["gelu_linear_mse"].map(finite_metric)].copy()
    paired["gain_vs_gelu_linear"] = (paired["gelu_linear_mse"] - paired["mse"]) / paired["gelu_linear_mse"]
    paired["win_vs_gelu_linear"] = paired["mse"] < paired["gelu_linear_mse"]
    return paired


def write_summary(path, raw, agg_df, placement, baseline):
    stage1 = raw[raw["run_id"].astype(str).str.contains("stage1", regex=False)] if "run_id" in raw.columns else raw.iloc[0:0]
    stage2 = raw[raw["run_id"].astype(str).str.contains("stage2", regex=False)] if "run_id" in raw.columns else raw.iloc[0:0]
    best = best_cells(agg_df)
    ranking = static_ranking(agg_df)
    stage1_cells = stage1[["dataset", "pred_len"]].drop_duplicates().shape[0] if not stage1.empty else 0
    stage2_cells = stage2[["dataset", "pred_len"]].drop_duplicates().shape[0] if not stage2.empty else 0
    placement_summary = pd.DataFrame()
    if not placement.empty:
        placement_summary = (
            placement.groupby("base_activation")
            .agg(
                paired_seed_runs=("output_tanh_gain", "size"),
                output_tanh_win_rate=("output_tanh_win", "mean"),
                output_tanh_gain_mean=("output_tanh_gain", "mean"),
                output_tanh_gain_median=("output_tanh_gain", "median"),
            )
            .reset_index()
            .sort_values("output_tanh_gain_mean", ascending=False)
        )
    baseline_summary = pd.DataFrame()
    if not baseline.empty:
        baseline_summary = (
            baseline.groupby("config_name")
            .agg(
                seed_win_rate=("win_vs_gelu_linear", "mean"),
                mean_gain_vs_gelu_linear=("gain_vs_gelu_linear", "mean"),
                median_gain_vs_gelu_linear=("gain_vs_gelu_linear", "median"),
                paired_seed_runs=("gain_vs_gelu_linear", "size"),
            )
            .reset_index()
            .sort_values("mean_gain_vs_gelu_linear", ascending=False)
        )
    out_best = int(best["config_name"].astype(str).str.contains("outtanh", regex=False).sum()) if not best.empty else 0
    total_best = best[CELL_COLS].drop_duplicates().shape[0] if not best.empty else 0
    lines = [
        "# PatchTST Transfer Report",
        "",
        f"- Raw finite seed-runs: {len(raw)}",
        f"- Stage1 dataset-horizon cells: {stage1_cells}",
        f"- Stage2 dataset-horizon cells: {stage2_cells}",
        f"- Complete config cells: {int((agg_df['seed_count'] >= 3).sum()) if not agg_df.empty else 0}",
        f"- Best cells using output tanh placement: {out_best}/{total_best}",
        "",
        "## Overall Ranking",
        "",
        markdown_table(ranking),
        "",
        "## Output Tanh vs Linear Placement",
        "",
        markdown_table(placement_summary),
        "",
        "## Paired Gain vs GELU Linear",
        "",
        markdown_table(baseline_summary),
        "",
        "## Best Cells",
        "",
        markdown_table(best[["dataset", "pred_len", "config_name", "mse_mean", "mse_std", "mae_mean", "rank_in_cell"]] if not best.empty else best),
    ]
    with open(path, "w", encoding="utf-8") as handle:
        handle.write("\n".join(lines) + "\n")


def main():
    parser = argparse.ArgumentParser(description="Aggregate PatchTST transfer and placement results")
    parser.add_argument("--output_dir", default="patchtst_remote_results/analysis_patchtst_transfer_actfix")
    parser.add_argument("--stage1_run_id", default="patchtst_stage1_20260521_actfix")
    parser.add_argument("--stage2_run_id", default="patchtst_stage2_20260521_actfix")
    parser.add_argument("--train_epochs", type=int, default=20)
    args = parser.parse_args()
    os.makedirs(args.output_dir, exist_ok=True)

    raw = load_raw([args.stage1_run_id, args.stage2_run_id], args.train_epochs)
    agg_df = aggregate(raw)
    placement = placement_paired(raw)
    baseline = baseline_paired(raw)
    raw.to_csv(os.path.join(args.output_dir, "patchtst_transfer_raw.csv"), index=False)
    agg_df.to_csv(os.path.join(args.output_dir, "patchtst_transfer_aggregate.csv"), index=False)
    best_cells(agg_df).to_csv(os.path.join(args.output_dir, "patchtst_transfer_best_cells.csv"), index=False)
    static_ranking(agg_df).to_csv(os.path.join(args.output_dir, "patchtst_transfer_static_ranking.csv"), index=False)
    placement.to_csv(os.path.join(args.output_dir, "patchtst_output_tanh_paired.csv"), index=False)
    baseline.to_csv(os.path.join(args.output_dir, "patchtst_vs_gelu_linear_paired.csv"), index=False)
    summary_path = os.path.join(args.output_dir, "patchtst_transfer_claim_summary.md")
    write_summary(summary_path, raw, agg_df, placement, baseline)
    print(summary_path)


if __name__ == "__main__":
    main()
