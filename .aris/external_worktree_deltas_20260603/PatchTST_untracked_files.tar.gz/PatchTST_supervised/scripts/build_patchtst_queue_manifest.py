#!/usr/bin/env python3
import argparse
import json
import os
import shlex
from datetime import datetime

import pandas as pd

from patchtst_common import HOST_PRIORITY, CONFIGS, setting_name


def shell_join(args):
    return " ".join(shlex.quote(str(arg)) for arg in args)


def server_id_for_host(host):
    return host.replace("10.21.53.", "4090-")


def command_for_row(row, run_tag, server_id, server_ip, save_arrays):
    config = CONFIGS[row["config_name"]]
    des = f"{run_tag}_{row['config_name']}_s{int(row['seed'])}"
    model_id = f"{row['dataset']}_pl{int(row['pred_len'])}_{row['config_name']}_s{int(row['seed'])}"
    args = [
        "python",
        "-u",
        "run_longExp.py",
        "--random_seed",
        int(row["seed"]),
        "--is_training",
        1,
        "--root_path",
        row["root_path"],
        "--data_path",
        row["data_path"],
        "--model_id",
        model_id,
        "--model",
        "PatchTST",
        "--data",
        row["data"],
        "--features",
        "M",
        "--target",
        row["target"],
        "--freq",
        row["freq"],
        "--seq_len",
        int(row["seq_len"]),
        "--label_len",
        int(row["label_len"]),
        "--pred_len",
        int(row["pred_len"]),
        "--enc_in",
        int(row["enc_in"]),
        "--dec_in",
        int(row["enc_in"]),
        "--c_out",
        int(row["c_out"]),
        "--e_layers",
        int(row["e_layers"]),
        "--d_layers",
        1,
        "--n_heads",
        int(row["n_heads"]),
        "--d_model",
        int(row["d_model"]),
        "--d_ff",
        int(row["d_ff"]),
        "--factor",
        1,
        "--dropout",
        float(row["dropout"]),
        "--fc_dropout",
        float(row["fc_dropout"]),
        "--head_dropout",
        0,
        "--patch_len",
        int(row["patch_len"]),
        "--stride",
        int(row["stride"]),
        "--padding_patch",
        "end",
        "--revin",
        1,
        "--affine",
        0,
        "--subtract_last",
        0,
        "--decomposition",
        0,
        "--embed",
        "timeF",
        "--des",
        des,
        "--train_epochs",
        int(row["train_epochs"]),
        "--patience",
        5,
        "--lradj",
        row["lradj"],
        "--pct_start",
        float(row["pct_start"]),
        "--itr",
        1,
        "--batch_size",
        int(row["batch_size"]),
        "--learning_rate",
        row["learning_rate"],
        "--num_workers",
        4,
        "--activation",
        config["activation"],
        "--output_activation",
        config["output_activation"],
        "--perturb_amplitude",
        float(config.get("amplitude", 0.0)),
        "--perturb_frequency",
        1.0,
        "--perturb_phase",
        0.0,
        "--gpu",
        "${GPU}",
        "--server_id",
        server_id,
        "--server_ip",
        server_ip,
        "--run_id",
        run_tag,
    ]
    if not save_arrays:
        args.extend(["--no_save_pred", "--no_save_true"])
    return shell_join(args)


def job_priority(row):
    order = {"smoke": 0, "stage1": 1, "stage2": 2}
    dataset_order = {"ETTh2": 0, "ETTm2": 1, "Solar2": 2, "Solar3": 3, "Solar5": 4}
    return (order.get(row["stage"], 9), dataset_order.get(row["dataset"], 9), int(row["pred_len"]), row["config_name"], int(row["seed"]))


def split_host(row, hosts):
    if str(row["dataset"]).startswith("ETT"):
        return hosts[(int(row["pred_len"]) + (0 if row["dataset"] == "ETTh2" else 1)) % len(hosts)]
    solar_idx = {"Solar2": 1, "Solar3": 2, "Solar5": 4}.get(row["dataset"], 0)
    return hosts[solar_idx % len(hosts)]


def build_payloads(missing, hosts, run_tag, remote_cwd, venv_path, max_parallel, gpus, save_arrays, assignment):
    manifests = {host: [] for host in hosts}
    for idx, row in enumerate(sorted(missing.to_dict("records"), key=job_priority)):
        host = hosts[idx % len(hosts)] if assignment == "round_robin" else split_host(row, hosts)
        server_id = server_id_for_host(host)
        job_id = f"ptst_{row['stage']}_{row['dataset']}_pl{int(row['pred_len'])}_{row['config_name']}_s{int(row['seed'])}"
        expected_output = f"results/{setting_name(row, run_tag)}/config.json"
        manifests[host].append(
            {
                "id": job_id,
                "cmd": command_for_row(row, run_tag, server_id, host, save_arrays),
                "expected_output": expected_output,
            }
        )
    payloads = {}
    for host, jobs in manifests.items():
        phases = []
        by_phase = {}
        for job in jobs:
            phase = job["id"].split("_", 2)[1]
            by_phase.setdefault(phase, []).append(job)
        for phase in ["smoke", "stage1", "stage2"]:
            if phase in by_phase:
                phases.append({"name": phase, "depends_on": [], "jobs": by_phase[phase]})
        payloads[host] = {
            "project": f"patchtst_activation_transfer_{host}",
            "cwd": remote_cwd,
            "venv_path": venv_path,
            "gpus": gpus,
            "max_parallel": max_parallel,
            "gpu_free_threshold_mib": 500,
            "oom_retry": {"delay": 180, "max_attempts": 2},
            "phases": phases,
        }
    return payloads


def main():
    parser = argparse.ArgumentParser(description="Build PatchTST remote queue manifests")
    parser.add_argument("missing_runs_csv")
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--run_tag", default="")
    parser.add_argument("--host", action="append", default=[])
    parser.add_argument("--remote_cwd", default="/home/testsv/project/osc_informer/PatchTST/PatchTST_supervised")
    parser.add_argument("--venv_path", default="/home/testsv/project/osc_informer/lee_ocil/.venv")
    parser.add_argument("--max_parallel", type=int, default=1)
    parser.add_argument("--gpus", default="0")
    parser.add_argument("--save_arrays", action="store_true")
    parser.add_argument("--assignment", choices=["dataset", "round_robin"], default="dataset")
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    missing = pd.read_csv(args.missing_runs_csv)
    run_tag = args.run_tag or f"patchtst_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    hosts = args.host or HOST_PRIORITY
    gpus = [int(item) for item in args.gpus.split(",") if item.strip()]
    payloads = build_payloads(
        missing,
        hosts,
        run_tag,
        args.remote_cwd,
        args.venv_path,
        args.max_parallel,
        gpus,
        args.save_arrays,
        args.assignment,
    )
    summary_rows = []
    for host, payload in payloads.items():
        job_count = sum(len(phase["jobs"]) for phase in payload["phases"])
        if not job_count:
            continue
        path = os.path.join(args.output_dir, f"patchtst_queue_manifest_{host.replace('.', '_')}.json")
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2)
        summary_rows.append({"host": host, "jobs": job_count, "manifest": path})
        print(f"Wrote {path}: {job_count} jobs")
    pd.DataFrame(summary_rows).to_csv(os.path.join(args.output_dir, "patchtst_queue_manifest_summary.csv"), index=False)


if __name__ == "__main__":
    main()
