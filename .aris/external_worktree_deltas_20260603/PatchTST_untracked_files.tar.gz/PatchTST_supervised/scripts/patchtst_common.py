import glob
import math
import os
import re

import pandas as pd


SEEDS = [2024, 2025, 2026]

HOST_PRIORITY = ["10.21.53.62", "10.21.53.82", "10.21.53.113", "10.21.53.142", "10.21.53.162"]

CONFIGS = {
    "gelu_ffn_linear": {"activation": "gelu", "output_activation": "linear", "amplitude": 0.0},
    "tanh_ffn_linear": {"activation": "tanh", "output_activation": "linear", "amplitude": 0.0},
    "softsign_ffn_linear": {"activation": "softsign", "output_activation": "linear", "amplitude": 0.0},
    "tanh_sin001_ffn_linear": {"activation": "tanh_sin", "output_activation": "linear", "amplitude": 0.01},
    "gelu_ffn_outtanh": {"activation": "gelu", "output_activation": "tanh", "amplitude": 0.0},
    "tanh_ffn_outtanh": {"activation": "tanh", "output_activation": "tanh", "amplitude": 0.0},
    "tanh_sin001_ffn_outtanh": {"activation": "tanh_sin", "output_activation": "tanh", "amplitude": 0.01},
}

STAGE1_CONFIGS = [
    "gelu_ffn_linear",
    "tanh_ffn_linear",
    "softsign_ffn_linear",
    "tanh_sin001_ffn_linear",
]

STAGE2_CONFIGS = [
    "gelu_ffn_outtanh",
    "tanh_ffn_outtanh",
    "tanh_sin001_ffn_outtanh",
]

SOLAR_FILES = {
    "Solar2": "Site_2_130MW.csv",
    "Solar3": "Site_3_30MW.csv",
    "Solar5": "Site_5_110MW.csv",
}

SMOKE_ROWS = {
    ("ETTh2", 336, "gelu_ffn_linear", 2024),
    ("ETTh2", 336, "tanh_sin001_ffn_linear", 2024),
    ("ETTm2", 288, "gelu_ffn_linear", 2024),
    ("ETTm2", 288, "tanh_ffn_linear", 2024),
    ("Solar3", 96, "gelu_ffn_linear", 2024),
    ("Solar3", 96, "tanh_sin001_ffn_linear", 2024),
    ("Solar5", 96, "gelu_ffn_linear", 2024),
    ("Solar5", 96, "softsign_ffn_linear", 2024),
}

SUMMARY_GLOBS = [
    "PatchTST/PatchTST_supervised/results/summary.csv",
    "patchtst_remote_results/*/results/summary.csv",
    "patchtst_remote_results/*/*/results/summary.csv",
]


def activation_signature(config_name):
    config = CONFIGS[config_name]
    return (
        f"act={config['activation']}|ffn={config['activation']}|"
        f"out={config['output_activation']}|a={float(config.get('amplitude', 0.0)):g}"
    )


def config_from_signature(signature, placement=None):
    for name in CONFIGS:
        if activation_signature(name) == signature and (placement is None or placement_for_config(name) == placement):
            return name
    return ""


def placement_for_config(config_name):
    output = CONFIGS[config_name]["output_activation"]
    return "ffn_linear" if output == "linear" else f"ffn_out{output}"


def dataset_protocol(dataset, pred_len):
    if dataset == "ETTh2":
        return {
            "data": "ETTh2",
            "root_path": "../../lee_ocil/ETT-small/",
            "data_path": "ETTh2.csv",
            "target": "OT",
            "freq": "h",
            "enc_in": 7,
            "c_out": 7,
            "seq_len": 336,
            "label_len": 48,
            "e_layers": 3,
            "d_model": 16,
            "n_heads": 4,
            "d_ff": 128,
            "dropout": 0.3,
            "fc_dropout": 0.3,
            "lradj": "type3",
            "pct_start": 0.3,
        }
    if dataset == "ETTm2":
        return {
            "data": "ETTm2",
            "root_path": "../../lee_ocil/ETT-small/",
            "data_path": "ETTm2.csv",
            "target": "OT",
            "freq": "t",
            "enc_in": 7,
            "c_out": 7,
            "seq_len": 336,
            "label_len": 48,
            "e_layers": 3,
            "d_model": 128,
            "n_heads": 16,
            "d_ff": 256,
            "dropout": 0.2,
            "fc_dropout": 0.2,
            "lradj": "TST",
            "pct_start": 0.4,
        }
    if dataset in SOLAR_FILES:
        return {
            "data": "custom",
            "root_path": "../../Solar/",
            "data_path": SOLAR_FILES[dataset],
            "target": "Power",
            "freq": "t",
            "enc_in": 6,
            "c_out": 6,
            "seq_len": 96,
            "label_len": 48,
            "e_layers": 3,
            "d_model": 128,
            "n_heads": 8,
            "d_ff": 256,
            "dropout": 0.2,
            "fc_dropout": 0.2,
            "lradj": "TST",
            "pct_start": 0.4,
        }
    raise ValueError(f"Unsupported PatchTST dataset: {dataset}")


def stage1_cells():
    cells = []
    for pred_len in [168, 336, 720]:
        cells.append(("ETTh2", pred_len))
    for pred_len in [96, 288, 672]:
        cells.append(("ETTm2", pred_len))
    for dataset in ["Solar2", "Solar3", "Solar5"]:
        for pred_len in [24, 96]:
            cells.append((dataset, pred_len))
    return cells


def stage2_cells():
    return [
        ("ETTh2", 336),
        ("ETTh2", 720),
        ("ETTm2", 288),
        ("ETTm2", 672),
        ("Solar3", 96),
        ("Solar5", 96),
    ]


def expected_rows(stage, train_epochs=20, batch_size=128):
    rows = []
    if stage in {"stage1", "all"}:
        for dataset, pred_len in stage1_cells():
            protocol = dataset_protocol(dataset, pred_len)
            for config_name in STAGE1_CONFIGS:
                for seed in SEEDS:
                    rows.append(row_for(dataset, pred_len, config_name, seed, protocol, "stage1", train_epochs, batch_size))
    if stage in {"stage2", "all"}:
        for dataset, pred_len in stage2_cells():
            protocol = dataset_protocol(dataset, pred_len)
            for config_name in STAGE2_CONFIGS:
                for seed in SEEDS:
                    rows.append(row_for(dataset, pred_len, config_name, seed, protocol, "stage2", train_epochs, batch_size))
    if stage == "smoke":
        for dataset, pred_len, config_name, seed in sorted(SMOKE_ROWS):
            protocol = dataset_protocol(dataset, pred_len)
            rows.append(row_for(dataset, pred_len, config_name, seed, protocol, "smoke", 3, batch_size))
    return pd.DataFrame(rows)


def row_for(dataset, pred_len, config_name, seed, protocol, stage, train_epochs, batch_size):
    config = CONFIGS[config_name]
    row = {
        "stage": stage,
        "dataset": dataset,
        "pred_len": int(pred_len),
        "config_name": config_name,
        "activation": config["activation"],
        "output_activation": config["output_activation"],
        "perturb_amplitude": float(config.get("amplitude", 0.0)),
        "perturb_frequency": 1.0,
        "perturb_phase": 0.0,
        "activation_signature": activation_signature(config_name),
        "placement": placement_for_config(config_name),
        "seed": int(seed),
        "batch_size": int(batch_size),
        "train_epochs": int(train_epochs),
        "patch_len": 16,
        "stride": 8,
        "d_layers": 1,
        "factor": 1,
        "learning_rate": 1e-4,
        "features": "M",
        "model": "PatchTST",
        **protocol,
    }
    return row


def setting_name(row, run_tag):
    model_id = f"{row['dataset']}_pl{int(row['pred_len'])}_{row['config_name']}_s{int(row['seed'])}"
    des = f"{run_tag}_{row['config_name']}_s{int(row['seed'])}"
    return (
        f"{model_id}_PatchTST_{row['data']}_ftM_sl{int(row['seq_len'])}_ll{int(row['label_len'])}"
        f"_pl{int(row['pred_len'])}_dm{int(row['d_model'])}_nh{int(row['n_heads'])}"
        f"_el{int(row['e_layers'])}_dl1_df{int(row['d_ff'])}_fc1_ebtimeF_dtTrue_{des}_0"
    )


def protocol_key_columns():
    return [
        "stage",
        "dataset",
        "pred_len",
        "seq_len",
        "patch_len",
        "stride",
        "e_layers",
        "d_model",
        "n_heads",
        "d_ff",
        "batch_size",
        "train_epochs",
        "activation_signature",
        "placement",
        "seed",
    ]


def read_existing_summaries():
    frames = []
    for pattern in SUMMARY_GLOBS:
        for path in glob.glob(pattern):
            try:
                frame = pd.read_csv(path)
            except (OSError, pd.errors.EmptyDataError):
                continue
            frame["summary_path"] = path
            frames.append(frame)
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def normalize_summary(summary):
    if summary.empty:
        return summary
    df = summary.copy()
    if "stage" not in df.columns:
        df["stage"] = ""
    if "run_id" in df.columns:
        run_id = df["run_id"].fillna("").astype(str)
        df.loc[df["stage"].eq("") & run_id.str.contains("smoke", regex=False), "stage"] = "smoke"
        df.loc[df["stage"].eq("") & run_id.str.contains("stage1", regex=False), "stage"] = "stage1"
        df.loc[df["stage"].eq("") & run_id.str.contains("stage2", regex=False), "stage"] = "stage2"
    if "dataset" not in df.columns:
        df["dataset"] = ""
    df["dataset"] = df["dataset"].replace({"custom": ""})
    if "activation_signature" not in df.columns:
        df["activation_signature"] = df.apply(
            lambda row: f"act={row.get('activation', '')}|ffn={row.get('activation', '')}|out={row.get('output_activation', 'linear')}|a={float(row.get('perturb_amplitude', 0.0)):g}",
            axis=1,
        )
    if "placement" not in df.columns:
        df["placement"] = df["output_activation"].fillna("linear").map(lambda x: "ffn_linear" if str(x).lower() == "linear" else f"ffn_out{x}")
    numeric = ["pred_len", "seq_len", "patch_len", "stride", "e_layers", "d_model", "n_heads", "d_ff", "batch_size", "train_epochs", "seed", "mse", "mae"]
    for col in numeric:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    return df


def finite_metric(value):
    try:
        return math.isfinite(float(value))
    except (TypeError, ValueError):
        return False


def with_source_priority(df):
    out = df.copy()
    out["_source_priority"] = 0
    if "run_id" not in out.columns or "summary_path" not in out.columns:
        return out
    run_id = out["run_id"].fillna("").astype(str)
    path = out["summary_path"].fillna("").astype(str)
    for stage in ["smoke", "stage1", "stage2"]:
        out.loc[run_id.str.contains(stage, regex=False) & path.str.contains(stage, regex=False), "_source_priority"] = 1
    return out
