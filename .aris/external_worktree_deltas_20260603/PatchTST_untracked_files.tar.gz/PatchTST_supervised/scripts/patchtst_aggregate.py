#!/usr/bin/env python3
import argparse
import os

import numpy as np
import pandas as pd

from patchtst_common import config_from_signature, finite_metric, normalize_summary, read_existing_summaries, with_source_priority


CELL_COLS = [
    "dataset",
    "pred_len",
    "seq_len",
    "patch_len",
    "stride",
    "e_layers",
    "d_model",
    "n_heads",
    "d_ff",
    "batch_size",
    "train_epochs",
]
KEYS = CELL_COLS + ["config_name", "activation_signature", "placement", "seed"]


def markdown_table(frame):
    if frame.empty:
        return ""
    cols = list(frame.columns)
    lines = [
        "| " + " | ".join(cols) + " |",
        "| " + " | ".join(["---"] * len(cols)) + " |",
    ]
    for row in frame.to_dict("records"):
        lines.append("| " + " | ".join(str(row.get(col, "")) for col in cols) + " |")
    return "\n".join(lines)


def add_config_names(df):
    out = df.copy()
    out["config_name"] = out.apply(
        lambda row: config_from_signature(row.get("activation_signature", ""), row.get("placement", None)),
        axis=1,
    )
    return out


def aggregate(raw):
    group_cols = CELL_COLS + ["config_name", "activation_signature", "placement"]
    return (
        raw.groupby(group_cols, dropna=False)
        .agg(
            seed_count=("seed", "nunique"),
            mse_mean=("mse", "mean"),
            mse_std=("mse", "std"),
            mae_mean=("mae", "mean"),
            mae_std=("mae", "std"),
        )
        .reset_index()
    )


def paired_vs_gelu(raw):
    merge_cols = CELL_COLS + ["seed"]
    baseline = raw[raw["config_name"] == "gelu_ffn_linear"][
        merge_cols + ["mse", "mae"]
    ].rename(columns={"mse": "gelu_mse", "mae": "gelu_mae"})
    paired = raw.merge(baseline, on=merge_cols, how="left")
    paired["improvement_vs_gelu"] = (paired["gelu_mse"] - paired["mse"]) / paired["gelu_mse"]
    paired["win_vs_gelu"] = paired["mse"] < paired["gelu_mse"]
    return paired


def best_cells(agg_df):
    eligible = agg_df[agg_df["seed_count"] >= 3].copy()
    if eligible.empty:
        return eligible
    eligible["rank"] = eligible.groupby(CELL_COLS)["mse_mean"].rank(method="min")
    return eligible[eligible["rank"] == 1].sort_values(["dataset", "pred_len"])


def write_claim_summary(path, raw, agg_df, paired):
    eligible = agg_df[agg_df["seed_count"] >= 3].copy()
    best = best_cells(agg_df)
    non_gelu_best = int((best["config_name"] != "gelu_ffn_linear").sum()) if not best.empty else 0
    total_cells = best[CELL_COLS].drop_duplicates().shape[0] if not best.empty else 0
    rank = eligible.copy()
    if not rank.empty:
        rank["rank_in_cell"] = rank.groupby(CELL_COLS)["mse_mean"].rank(method="min")
        static = (
            rank.groupby("config_name", dropna=False)
            .agg(
                mean_rank=("rank_in_cell", "mean"),
                best_cells=("rank_in_cell", lambda x: int((x == 1).sum())),
                mean_mse=("mse_mean", "mean"),
            )
            .reset_index()
            .sort_values(["mean_rank", "mean_mse"])
        )
    else:
        static = pd.DataFrame()
    paired_complete = paired[paired["gelu_mse"].map(finite_metric)].copy()
    lines = [
        "# PatchTST Activation Transfer Claim Summary",
        "",
        f"- Raw finite seed-runs: {len(raw)}",
        f"- Complete 3-seed config cells: {int((eligible['seed_count'] >= 3).sum()) if not eligible.empty else 0}",
        f"- Dataset-horizon cells with non-GELU best activation: {non_gelu_best}/{total_cells}",
        "",
        "## Static Ranking",
        "",
    ]
    if static.empty:
        lines.append("No complete ranking yet.")
    else:
        lines.append(markdown_table(static.head(10)))
    if not best.empty:
        lines.extend(["", "## Best Cells", "", markdown_table(best)])
    if not paired_complete.empty:
        positive = paired_complete.groupby("config_name")["win_vs_gelu"].mean().reset_index(name="seed_win_rate")
        gain = paired_complete.groupby("config_name")["improvement_vs_gelu"].mean().reset_index(name="mean_gain_vs_gelu")
        lines.extend(["", "## Paired vs GELU", "", markdown_table(positive.merge(gain, on="config_name"))])
    with open(path, "w", encoding="utf-8") as handle:
        handle.write("\n".join(lines) + "\n")


def main():
    parser = argparse.ArgumentParser(description="Aggregate PatchTST activation transfer results")
    parser.add_argument("--output_dir", default="patchtst_remote_results/analysis_current")
    parser.add_argument("--run_id_contains", default="")
    parser.add_argument("--train_epochs", type=int, default=None)
    args = parser.parse_args()
    os.makedirs(args.output_dir, exist_ok=True)
    raw = read_existing_summaries()
    if raw.empty:
        raise SystemExit("No PatchTST summaries found")
    raw = normalize_summary(raw)
    raw = raw[raw["mse"].map(finite_metric) & raw["mae"].map(finite_metric)].copy()
    if args.run_id_contains:
        if "run_id" not in raw.columns:
            raw = raw.iloc[0:0].copy()
        else:
            raw = raw[raw["run_id"].astype(str).str.contains(args.run_id_contains, regex=False)].copy()
    if args.train_epochs is not None and "train_epochs" in raw.columns:
        raw = raw[raw["train_epochs"].eq(args.train_epochs)].copy()
    raw = add_config_names(raw)
    raw = raw[raw["config_name"] != ""].copy()
    raw = with_source_priority(raw)
    raw = raw.sort_values(["dataset", "pred_len", "config_name", "seed", "_source_priority", "summary_path"]).drop_duplicates(KEYS, keep="last")
    raw = raw.drop(columns=["_source_priority"], errors="ignore")
    agg_df = aggregate(raw)
    paired = paired_vs_gelu(raw)

    raw.to_csv(os.path.join(args.output_dir, "patchtst_protocol_raw_dedup.csv"), index=False)
    agg_df.to_csv(os.path.join(args.output_dir, "patchtst_protocol_aggregate.csv"), index=False)
    paired.to_csv(os.path.join(args.output_dir, "patchtst_paired_vs_gelu.csv"), index=False)
    best_cells(agg_df).to_csv(os.path.join(args.output_dir, "patchtst_best_cells.csv"), index=False)
    write_claim_summary(os.path.join(args.output_dir, "patchtst_claim_summary.md"), raw, agg_df, paired)
    print(os.path.join(args.output_dir, "patchtst_claim_summary.md"))


if __name__ == "__main__":
    main()
